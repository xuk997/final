package com.example.picture;

import android.app.Activity;
import android.os.Bundle;

public class login extends Activity {
    @Override

    protected void onCreate(Bundle savadInstanceState){
        super.onCreate(savadInstanceState);
        setContentView(R.layout.login);
    }
}
