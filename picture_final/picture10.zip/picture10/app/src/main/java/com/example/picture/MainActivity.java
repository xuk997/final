package com.example.picture;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import java.io.File;
import java.io.FileNotFoundException;
import android.database.Cursor;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import android.graphics.Canvas;
import android.graphics.Paint;

//import org.json.JSONArray;
//import org.json.JSONObject;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static java.lang.Integer.parseInt;


public class MainActivity extends AppCompatActivity {

    private Paint mPaint = null;
    private Uri imgUri; //记录拍照后的照片文件的地址(临时文件)
    private Uri imgUri1;
    private byte[] fileBuf1;
    private ImageView imgView;//用于查看照片的view
    private Button butturn;//用于页面跳转
    private String uploadFileName;
    private String uploadFileName1;
    private byte[] fileBuf;
    private Bitmap bitmap;
    private Bitmap bitmap_1;
    private ImageView rmgView;//查看第二张view
    private String uploadUrl = "http://39.106.224.238:8000/upload";
    static String detectUrl="https://aip.baidubce.com/rest/2.0/face/v3/detect?access_token=24.eda7436c0e1995140c07b4ccbe543b86.2592000.1576160127.282335-17757423";
    static String searchUrl="https://aip.baidubce.com/rest/2.0/face/v3/search?access_token=24.eda7436c0e1995140c07b4ccbe543b86.2592000.1576160127.282335-17757423";//链接百度人脸搜索端口（尚未调通）
    private String s;
    private TextView showtext;
    private TextView showtextp;
    private String rs_s;
    private String rs_c;
    private String rs_d;
    private String age[];
    private String gender[];
    private String left[];
    private String top[];
    private String width[];
    private String height[];
    private String face_num;
    private  String str[];
    private RecyclerView recyclerview;
    private List<content> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.photo);
        imgView=findViewById(R.id.pupload);
        rmgView=findViewById(R.id.download);
        showtext=findViewById(R.id.showtext);
        recyclerview = findViewById(R.id.recyclerview);
//        butturn=findViewById(R.id.turnewb);//id后面为上方button的id
//
//        butturn.setOnClickListener(new View.OnClickListener() {//跳转页面的函数
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent();
//                intent.setClass(MainActivity.this, ResultActivity.class);//this前面为当前activty名称，class前面为要跳转到得activity名称
//                startActivity(intent);
//            }
//        });//跳转页面
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void getPrem(View view) {
        if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},1);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode){
            case 1:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    //得到了用户的允许
                }
                else{
                    //用户拒绝
                }break;
            case 2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openGallery();
                } else {
                    Toast.makeText(this, "读相册的操作被拒绝", Toast.LENGTH_LONG).show();
                }break;
        }
    }
    public void photo(View view) throws Exception{

        //删除并创建临时文件，用于保存拍照后的照片
        //android 6以后，写Sdcard是危险权限，需要运行时申请，但此处使用的是"关联目录"，无需！
        File outImg=new File(getExternalCacheDir(),"temp.jpg");
        if(outImg.exists()) outImg.delete();
        outImg.createNewFile();

        //复杂的Uri创建方式
        if(Build.VERSION.SDK_INT>=24)
            //这是Android 7后，更加安全的获取文件uri的方式（需要配合Provider,在Manifest.xml中加以配置）
            imgUri= FileProvider.getUriForFile(this,"com.example.app1.fileprovider",outImg);
        else
            imgUri=Uri.fromFile(outImg);

        //利用actionName和Extra,启动《相机Activity》
        Intent intent=new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra(MediaStore.EXTRA_OUTPUT,imgUri);
        startActivityForResult(intent,1);
    }

    public void photo1(View view) throws Exception{

        //删除并创建临时文件，用于保存拍照后的照片
        //android 6以后，写Sdcard是危险权限，需要运行时申请，但此处使用的是"关联目录"，无需！
        File outImg=new File(getExternalCacheDir(),"temp.jpg");
        if(outImg.exists()) outImg.delete();
        outImg.createNewFile();

        //复杂的Uri创建方式
        if(Build.VERSION.SDK_INT>=24)
            //这是Android 7后，更加安全的获取文件uri的方式（需要配合Provider,在Manifest.xml中加以配置）
            imgUri1= FileProvider.getUriForFile(this,"com.example.app1.fileprovider",outImg);
        else
            imgUri1=Uri.fromFile(outImg);

        //利用actionName和Extra,启动《相机Activity》
        Intent intent=new Intent("android.media.action.IMAGE_CAPTURE");
        intent.putExtra(MediaStore.EXTRA_OUTPUT,imgUri1);
        startActivityForResult(intent,3);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                //此时，相机拍照完毕
                if (resultCode == RESULT_OK) {
                    try {

                        //利用ContentResolver,查询临时文件，并使用BitMapFactory,从输入流中创建BitMap
                        //同样需要配合Provider,在Manifest.xml中加以配置
                        InputStream inputStream = getContentResolver().openInputStream(imgUri);
                        fileBuf = convertToBytes(inputStream);
                        bitmap = BitmapFactory.decodeByteArray(fileBuf, 0, fileBuf.length);
                        imgView.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }//cursor.close();
                }
                break;
            case 2:
                handleSelect(data);
                break;
            case 3:
                if (resultCode == RESULT_OK) {
                    try {

                        //利用ContentResolver,查询临时文件，并使用BitMapFactory,从输入流中创建BitMap
                        //同样需要配合Provider,在Manifest.xml中加以配置
                        InputStream inputStream = getContentResolver().openInputStream(imgUri1);
                        fileBuf1 = convertToBytes(inputStream);
                        bitmap_1 = BitmapFactory.decodeByteArray(fileBuf1, 0, fileBuf1.length);
                        rmgView.setImageBitmap(bitmap_1);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }//cursor.close();
                }break;
            case 4:
                handleSelect1(data);
                break;
        }
    }




    //按钮点击事件
    public void select(View view) {
        String[] permissions = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        //进行sdcard的读写请求
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, permissions, 2);
        } else {
            openGallery(); //打开相册，进行选择
        }
    }

    public void select1(View view) {
        String[] permissions = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        //进行sdcard的读写请求
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, permissions, 2);
        } else {
            openGallery1(); //打开相册，进行选择
        }
    }
    //打开相册,进行照片的选择
    private void openGallery() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        startActivityForResult(intent, 2);
    }
    private void openGallery1() {
        Intent intent = new Intent("android.intent.action.GET_CONTENT");
        intent.setType("image/*");
        startActivityForResult(intent, 4);
    }

    private void handleSelect1(Intent intent) {
        Cursor cursor = null;
        Uri uri = intent.getData();
        cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            uploadFileName1 = cursor.getString(columnIndex);
        }
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            fileBuf1=convertToBytes(inputStream);
            bitmap_1 = BitmapFactory.decodeByteArray(fileBuf1, 0, fileBuf1.length);
            rmgView.setImageBitmap(bitmap_1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        cursor.close();
    }

    //选择后照片的读取工作
    private void handleSelect(Intent intent) {
        Cursor cursor = null;
        Uri uri = intent.getData();
        cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            uploadFileName = cursor.getString(columnIndex);
        }
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            fileBuf=convertToBytes(inputStream);
            bitmap = BitmapFactory.decodeByteArray(fileBuf, 0, fileBuf.length);
            imgView.setImageBitmap(bitmap);
        } catch (Exception e) {
            e.printStackTrace();
        }
        cursor.close();
    }

    //文件上传的处理
    public void upload(View view) {
        new Thread() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient();
                //上传文件域的请求体部分
                RequestBody formBody = RequestBody
                        .create(fileBuf, MediaType.parse("image/jpeg"));
                //整个上传的请求体部分（普通表单+文件上传域）
                RequestBody requestBody = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("title", "Square Logo")
                        //filename:avatar,originname:abc.jpg
                        .addFormDataPart("avatar", uploadFileName, formBody)
                        .build();
                Request request = new Request.Builder()
                        .url(uploadUrl)
                        .post(requestBody)
                        .build();

                try {
                    Response response = client.newCall(request).execute();
                    Log.i("数据", response.body().string() + "....");
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        }.start();
    }

    private byte[] convertToBytes(InputStream inputStream) throws Exception{
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        int len = 0;
        while ((len = inputStream.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        out.close();
        inputStream.close();
        return  out.toByteArray();
    }

//expires_in:	2592000
//access_token	"24.eda7436c0e1995140c07b4ccbe543b86.2592000.1576160127.282335-17757423"
//appid:        17757423
//API Key:      IQutmO7N4MrHQ2BdBhuzrvVS
//Secret Key:    Ggz4bMTvGHyDIwzGiUIweM3qjYOY0u3O

    public void testSearchWithBase64(View view){
        new Thread()
        {
            public String bitmaptoBase64(Bitmap bitmap){
                s= null;
                ByteArrayOutputStream baos = null;
                try {
                    if(bitmap!=null)
                    {
                        baos = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                        baos.flush();
                        baos.close();
                        byte[] bitmapBytes = baos.toByteArray();
                        //   s = new String(Base64.encodeToString(bitmapBytes, Base64.DEFAULT));
                        s=Base64.encodeToString(bitmapBytes, Base64.DEFAULT);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (baos != null) {
                            baos.flush();
                            baos.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return  s;
            }
            public  String searchFaceWithBase64(String Base64,String groupIdList){
                rs_s="";
                OkHttpClient client = new OkHttpClient();
                RequestBody body=new FormBody.Builder()
                        .add("image_type","BASE64")
                        .add("image",Base64)
                        .add("group_id_list", groupIdList)
                        .build();
                Request request=new Request.Builder()
                        .url(searchUrl)
                        .header("Content-Type","application/json")
                        .post(body)
                        .build();

                try {
                    Response resp= client.newCall(request).execute();
                    rs_s = resp.body().string();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                return rs_s;
            }
            public void run()
            {
                String base64=this.bitmaptoBase64(bitmap);
//                String base64=this.toBase64(fileBuf);
                rs_s=this.searchFaceWithBase64(base64,"group001");
                JSONObject object = JSONObject
                        .parseObject(rs_s);
                JSONObject d =  object.getJSONObject("result");
                JSONArray d1=d.getJSONArray("user_list");
                JSONObject d2 = (JSONObject) d1.get(0);
                final String name = d2.getString("user_info");
                final String score=d2.getString("score");
                System.out.println(name);
                System.out.println(score);
               runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                       showtext.setText("最相似明星："+name+"\n相似度："+score);
                    }
                });

            }

        }.start();
    }
    public void testDetectWithBase64(View view){
        new Thread()
        {
            public String bitmaptoBase64(Bitmap bitmap){
                s= null;
                ByteArrayOutputStream baos = null;
                try {
                    if(bitmap!=null)
                    {
                        baos = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                        baos.flush();
                        baos.close();
                        byte[] bitmapBytes = baos.toByteArray();
                        //   s = new String(Base64.encodeToString(bitmapBytes, Base64.DEFAULT));
                        s=Base64.encodeToString(bitmapBytes, Base64.DEFAULT);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (baos != null) {
                            baos.flush();
                            baos.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return  s;
            }
            public String detectFaceWithBase64(String Base64){
                String rs_d="";
                OkHttpClient client = new OkHttpClient();
                RequestBody body=new FormBody.Builder()
                        .add("image_type","BASE64")
                        .add("image",Base64)
                        .add("max_face_num","10")
                        .add("face_field","age,beauty,gender,emotion")
                        .build();
                Request request=new Request.Builder()
                        .url(detectUrl)
                        .header("Content-Type","application/json")
                        .post(body)
                        .build();

                try {
                    Response resp= client.newCall(request).execute();
                    rs_d = resp.body().string();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return rs_d;
            }
            public void run() {
                String base64 = this.bitmaptoBase64(bitmap);
                rs_d = this.detectFaceWithBase64(base64);
                JSONObject object = JSONObject
                        .parseObject(rs_d);
                JSONObject d = object.getJSONObject("result");
                face_num = d.getString("face_num");
                System.out.println(face_num);
                int n = parseInt(face_num);
                age = new String[n];
                gender =new String[n];
                for (int i = 0; i < n; i++) {
                    JSONArray d1 = d.getJSONArray("face_list");
                    JSONObject face1 = (JSONObject) d1.get(i);
                    age[i] = face1.getString("age");
                    JSONObject gender_Ob1 = face1.getJSONObject("gender");
                    gender[i] = gender_Ob1.getString("type");
                    JSONObject location_1 = face1.getJSONObject("location");
//                    left[i] = location_1.getString("left");
//                    String top_1 = location_1.getString("top");
//                    width[i] = location_1.getString("width");
//                    height[i] = location_1.getString("height");
                }


                System.out.println(rs_d);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showtext.setText("检测到的人脸数目（从左至右）：" + face_num+"\n性别                             年龄");
                        int len=0;
                        for (int i = 0; i < parseInt(face_num); i++){
                            content content = new content();
                            content.setAge(Integer.parseInt(age[i]));
                            content.setSex(gender[i]);
                            System.out.println(gender[i]);
                            list.add(content);
                        }
                        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(list);
                        recyclerview.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                        recyclerview.setAdapter(recyclerAdapter);
                            //showtext.setText("分别是：" + age[i] + "  " + gender[i] + "  " + age[i] + "  " + gender[i]);
                    }
                });
            }
        }.start();
    }
    public void testCompareWithBase64(View view){
        new Thread()
        {
            public String bitmaptoBase64(Bitmap bitmap){
                s= null;
                ByteArrayOutputStream baos = null;
                try {
                    if(bitmap!=null)
                    {
                        baos = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                        baos.flush();
                        baos.close();
                        byte[] bitmapBytes = baos.toByteArray();
                        //   s = new String(Base64.encodeToString(bitmapBytes, Base64.DEFAULT));
                        s=Base64.encodeToString(bitmapBytes, Base64.DEFAULT);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    try {
                        if (baos != null) {
                            baos.flush();
                            baos.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                return  s;
            }
            public  String compareWithBase64(String uri_1,String uri_2)
            {
                rs_c=null;
                String url = "https://aip.baidubce.com/rest/2.0/face/v3/match";
                try {
                    Map<String, Object> map1=new HashMap<>();
                    map1.put("image", uri_1);
                    //  map1.put("liveness_control", "NORMAL");
                    map1.put("group_id_list", "02");
                    map1.put("image_type", "BASE64");
                    map1.put("quality_control", "LOW");

                    Map<String, Object> map2 = new HashMap<>();
                    map2.put("image", uri_2);
                    //             map2.put("liveness_control", "NORMAL");
                    map2.put("group_id_list", "02");
                    map2.put("image_type", "BASE64");
                    map2.put("quality_control", "LOW");
                    String param = "["+GsonUtils.toJson(map1)+","+GsonUtils.toJson(map2)+"]";

                    // 注意这里仅为了简化编码每一次请求都去获取access_token，线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
                    String accessToken = "24.9993b147df9bc4596b12406f12649206.2592000.1575730874.282335-17721725";

                    String rs_c = HttpUtil.post(url, accessToken, "application/json", param);
                    //System.out.println(result);
                    //rs_c=result;
                    return rs_c;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;

            }
            public void run()
            {
                String base64_1=this.bitmaptoBase64(bitmap);
                String base64_2=this.bitmaptoBase64(bitmap_1);
//                String base64=this.toBase64(fileBuf);
                rs_c=this.compareWithBase64(base64_1,base64_2);
                JSONObject object = JSONObject
                        .parseObject(rs_c);
                JSONObject d =  object.getJSONObject("result");
                final String score = d.getString("score");
                System.out.println(score);
               runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showtext.setText("相似度："+score);
                }
            });

            }

        }.start();
    }
}
//  百度页面布局，用于查找结构内容

