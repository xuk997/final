package com.example.picture;

import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.View;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main extends AppCompatActivity {
    public static final String TAG = "zhuce";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        DatabaseHelper databaseHelper = new DatabaseHelper(this,"test_db",null,1);
        final SQLiteDatabase db = databaseHelper.getWritableDatabase();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //login button
        Button login = (Button) findViewById(R.id.button);
        final String user=null,pass=null;
//        final String pass = "hello";
        login.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                String username=null,password=null,validnam=null;
                int exist=0;
                EditText editText1 = (EditText)findViewById(R.id.editText);
                username = editText1.getText().toString();
                EditText editText2 = (EditText)findViewById(R.id.editText2);
                password = editText2.getText().toString();
                Cursor cursor = db.query("user",null, null, null, null, null, null);
                while(cursor.moveToNext()){
                    validnam += cursor.getString(cursor.getColumnIndex("name"));
                }
//                Toast.makeText(getApplicationContext(),validnam,Toast .LENGTH_SHORT).show();
                exist= validnam.indexOf(","+username+","+password+",");
                if  (username!=null&&password!=null&&exist!=-1) {
                    Toast.makeText(getApplicationContext(),"登录成功"+username+","+password+","+exist,Toast .LENGTH_SHORT).show();
                    startActivity(new Intent(Main.this, MainActivity.class));
                }
                else{
                    Toast.makeText(getApplicationContext(),"密码错误？账号错误？还是你根本就没输入",Toast .LENGTH_SHORT).show();

                }

            }
            public void deleteTable(){//删除表
                String sqldelete="drop table Alarm";
                db.execSQL(sqldelete);}
        });
        //register button
        final Button register = (Button) findViewById(R.id.button2);
        register.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                //提示框确定是否跳转
                new AlertDialog.Builder(Main.this).setTitle("Jump").setMessage("Ready to jump?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Main.this, register.class);
                        startActivity(intent);
                    }})
                        .setNegativeButton("No",null)
                        .show();
            }

        });

    }

}
