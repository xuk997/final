package com.example.picture;//package com.baidu.ai.aip;

//import com.baidu.ai.aip.utils.HttpUtil;
//import com.baidu.ai.aip.utils.GsonUtils;

import android.os.Build;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.RequiresApi;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

//import org.json.JSONObject;
//import sun.misc.BASE64Encoder;

/**
 * 人脸搜索
 */
public class FaceSearch {
    static String addUrl="https://aip.baidubce.com/rest/2.0/face/v3/faceset/user/add?access_token=24.9993b147df9bc4596b12406f12649206.2592000.1575730874.282335-17721725";

    /**
     * 重要提示代码中所需工具类
     * FileUtil,Base64Util,HttpUtil,GsonUtils请从
     * https://ai.baidu.com/file/658A35ABAB2D404FBF903F64D47C1F72
     * https://ai.baidu.com/file/C8D81F3301E24D2892968F09AE1AD6E2
     * https://ai.baidu.com/file/544D677F5D4E4F17B4122FBD60DB82B3
     * https://ai.baidu.com/file/470B3ACCA3FE43788B5A963BF0B625F3
     * 下载
     * @return
     */

//    public static String toBase64(InputStream inputStream){
//        String s= null;
//        try {
//            byte[] buf=new byte[inputStream.available()];
//            inputStream.read(buf);
//            s = new Base64.getEncoder();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return  s;
//      }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String toBase64() throws IOException {
        InputStream inputStream=new FileInputStream("C:\\Users\\EXCELLENT--XMJ\\Desktop\\c01.jpg");
        OutputStream outputStream=new FileOutputStream("C:\\Users\\EXCELLENT--XMJ\\abc12.jpg");

        //文件读入缓存并编码
        byte[] buf=new byte[inputStream.available()];
        inputStream.read(buf);
        //编码
        String s=new String(Base64.getEncoder().encode(buf));

        //解码，并写入文件
//        byte[] buf1= Base64.getDecoder().decode(s);
//        outputStream.write(buf1);
//
//        outputStream.close();
//        inputStream.close();
        return s;
    }
    public static String faceSearch(String b) {
        // 请求url
        String url = "https://aip.baidubce.com/rest/2.0/face/v3/search";
        try {
            Map<String, Object> map = new HashMap<>();
            map.put("image", b);
            map.put("liveness_control", "NORMAL");
            map.put("group_id_list", "02");
            map.put("image_type", "BASE64");
            map.put("quality_control", "LOW");

            String param = GsonUtils.toJson(map);

            // 注意这里仅为了简化编码每一次请求都去获取access_token，线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
            String accessToken = "24.9993b147df9bc4596b12406f12649206.2592000.1575730874.282335-17721725";

            String result = HttpUtil.post(url, accessToken, "application/json", param);
            System.out.println(result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String addFaceWithBase64(String Base64, String groupId, String userId, String userInfo){
        String rs="";
        OkHttpClient client = new OkHttpClient();
        RequestBody body=new FormBody.Builder()
                .add("image_type","BASE64")
                .add("image",Base64)
                .add("group_id", groupId)
                .add("user_id", userId)
                .add("user_info",userInfo)
                .build();
        Request request=new Request.Builder()
                .url(addUrl)
                .header("Content-Type","application/json")
                .post(body)
                .build();

        try {
            Response resp= client.newCall(request).execute();
            rs = resp.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rs;
    }
    public static List getList(String jsonString) {
        List list = new ArrayList();
        try {
            Gson gson = new Gson();
            list = gson.fromJson(jsonString, new TypeToken<Object>() {
            }.getType());
        } catch (Exception e) {
            // TODO: handle exception
        }
        return list;
    }
//    @RequiresApi(api = Build.VERSION_CODES.O)
//    public static void main(String[] args) throws IOException, JSONException {
//        String b=toBase64();
//       String s=FaceSearch.faceSearch(b);
//        JSONObject object = JSONObject
//                .parseObject(s);
//        JSONObject d =  object.getJSONObject("result");
//        JSONArray d1=d.getJSONArray("user_list");
//        JSONObject d2 = (JSONObject) d1.get(0);
//        String name = d2.getString("user_info");
//        System.out.println(name);
//
//    }
}